package Actividad4;

import javax.swing.*;
import java.applet.Applet;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ejercicio8 extends Applet implements ActionListener {
    private MiHilo hilo1; // Hilo 1
    private MiHilo hilo2; // Hilo 2
    private Button iniciarButton; // Botón para iniciar ambos hilos
    private Button suspenderButton1; // Botón para suspender Hilo 1
    private Button reanudarButton1; // Botón para reanudar Hilo 1
    private Button suspenderButton2; // Botón para suspender Hilo 2
    private Button reanudarButton2; // Botón para reanudar Hilo 2
    private Button finalizarButton; // Botón para finalizar ambos hilos
    private Label contadorLabel1; // Etiqueta para mostrar el contador de Hilo 1
    private Label contadorLabel2; // Etiqueta para mostrar el contador de Hilo 2

    @Override
    public void init() {
        setLayout(new GridLayout(1, 3)); // Usamos un GridLayout para organizar los paneles

        // Inicialización de los hilos
        hilo1 = new MiHilo();
        hilo2 = new MiHilo();

        // Panel para el Hilo 1
        Panel panelHilo1 = new Panel();
        panelHilo1.setLayout(new GridLayout(5, 1)); // Cuatro filas para los botones y una para el contador

        contadorLabel1 = new Label("Valor del contador Hilo 1: 0");
        contadorLabel1.setFont(new Font("Serif", Font.BOLD, 16));
        panelHilo1.add(contadorLabel1); // Añadir la etiqueta del contador al panel

        // Inicialización de botones para el Hilo 1
        suspenderButton1 = new Button("Suspender Hilo 1");
        reanudarButton1 = new Button("Reanudar Hilo 1");
        suspenderButton1.addActionListener(this); // Añadir el ActionListener
        reanudarButton1.addActionListener(this);
        panelHilo1.add(suspenderButton1); // Añadir botones al panel
        panelHilo1.add(reanudarButton1);

        // Panel para el Hilo 2
        Panel panelHilo2 = new Panel();
        panelHilo2.setLayout(new GridLayout(5, 1));

        contadorLabel2 = new Label("Valor del contador Hilo 2: 0");
        contadorLabel2.setFont(new Font("Serif", Font.BOLD, 16));
        panelHilo2.add(contadorLabel2); // Añadir la etiqueta del contador al panel

        // Inicialización de botones para el Hilo 2
        suspenderButton2 = new Button("Suspender Hilo 2");
        reanudarButton2 = new Button("Reanudar Hilo 2");
        suspenderButton2.addActionListener(this); // Añadir el ActionListener
        reanudarButton2.addActionListener(this);
        panelHilo2.add(suspenderButton2); // Añadir botones al panel
        panelHilo2.add(reanudarButton2);

        // Panel de control
        Panel panelControl = new Panel();
        panelControl.setLayout(new GridLayout(4, 1)); // Tres filas para botones y una para iniciar
        iniciarButton = new Button("Iniciar Ambos Hilos");
        finalizarButton = new Button("Finalizar Ambos Hilos");

        iniciarButton.addActionListener(this); // Añadir ActionListener para iniciar
        finalizarButton.addActionListener(this); // Añadir ActionListener para finalizar

        panelControl.add(iniciarButton); // Añadir botón de iniciar al panel
        panelControl.add(finalizarButton); // Añadir botón de finalizar al panel

        // Añadir los paneles al applet
        add(panelHilo1);
        add(panelControl);
        add(panelHilo2);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Acción para iniciar ambos hilos
        if (e.getSource() == iniciarButton) {
            hilo1.start(); // Iniciar Hilo 1
            hilo2.start(); // Iniciar Hilo 2
            startCounterUpdateThread(hilo1, contadorLabel1); // Iniciar hilo para actualizar contador de Hilo 1
            startCounterUpdateThread(hilo2, contadorLabel2); // Iniciar hilo para actualizar contador de Hilo 2
            System.out.println("Ambos hilos iniciados.");
        } else if (e.getSource() == suspenderButton1) {
            hilo1.suspende(); // Suspender Hilo 1
            System.out.println("Hilo 1 suspendido.");
        } else if (e.getSource() == reanudarButton1) {
            hilo1.reanuda(); // Reanudar Hilo 1
            System.out.println("Hilo 1 reanudado.");
        } else if (e.getSource() == suspenderButton2) {
            hilo2.suspende(); // Suspender Hilo 2
            System.out.println("Hilo 2 suspendido.");
        } else if (e.getSource() == reanudarButton2) {
            hilo2.reanuda(); // Reanudar Hilo 2
            System.out.println("Hilo 2 reanudado.");
        } else if (e.getSource() == finalizarButton) {
            hilo1.detener(); // Detener Hilo 1
            hilo2.detener(); // Detener Hilo 2
            System.out.println("Ambos hilos finalizados.");
        }
    }

    // Método para iniciar un hilo que actualiza la etiqueta del contador
    private void startCounterUpdateThread(MiHilo hilo, Label contadorLabel) {
        new Thread(() -> {
            while (hilo.isAlive()) { // Mientras el hilo esté vivo
                try {
                    Thread.sleep(500); // Esperar 500 ms
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                contadorLabel.setText("Valor del contador: " + hilo.getContador()); // Actualizar la etiqueta
            }
        }).start(); // Iniciar el hilo de actualización
    }

    @Override
    public void stop() {
        // Detener ambos hilos si están vivos
        if (hilo1 != null && hilo1.isAlive()) {
            hilo1.detener(); // Detener Hilo 1
            try {
                hilo1.join(); // Esperar a que Hilo 1 termine
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(hilo1.getContador()); // Imprimir contador final de Hilo 1
        }

        if (hilo2 != null && hilo2.isAlive()) {
            hilo2.detener(); // Detener Hilo 2
            try {
                hilo2.join(); // Esperar a que Hilo 2 termine
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(hilo2.getContador()); // Imprimir contador final de Hilo 2
        }
    }
}
